package dk.cphbusiness.monopolywithmocking;

interface Cup {

    public void roll();

    public int getTotal();
    
}
